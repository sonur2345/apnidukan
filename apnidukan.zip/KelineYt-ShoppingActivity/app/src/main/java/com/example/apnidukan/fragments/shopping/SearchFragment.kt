package com.example.apnidukan.fragments.shopping

import androidx.fragment.app.Fragment
import com.example.apnidukan.R

class SearchFragment : Fragment(R.layout.fragment_search)